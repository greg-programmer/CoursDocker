import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AnnuaireView from './view/AnnuaireView/AnnuaireView';

function App() {
  return (
    <div className="App">
      <AnnuaireView/>
    </div>
  );
}

export default App;
